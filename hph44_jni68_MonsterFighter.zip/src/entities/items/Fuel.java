package entities.items;

public class Fuel extends Item {
    public Fuel() {
        super();
    }
}
